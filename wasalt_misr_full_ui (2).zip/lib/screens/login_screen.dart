import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class LoginScreen extends StatefulWidget {
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _pass = TextEditingController();
  bool _loading = false;
  final AuthService _auth = AuthService();

  void _login() async {
    setState(() { _loading = true; });
    try {
      await _auth.signIn(_email.text.trim(), _pass.text.trim());
      Navigator.pushReplacementNamed(context, '/home');
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('فشل تسجيل الدخول: \$e')));
    } finally {
      setState(() { _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text('وصلت مصر - تسجيل الدخول')),
        body: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            children: [
              TextField(controller: _email, decoration: InputDecoration(labelText: 'البريد الإلكتروني')),
              TextField(controller: _pass, decoration: InputDecoration(labelText: 'كلمة المرور'), obscureText: true),
              SizedBox(height: 20),
              _loading ? CircularProgressIndicator() :
              ElevatedButton(onPressed: _login, child: Text('تسجيل الدخول')),
              TextButton(onPressed: (){ Navigator.pushNamed(context, '/register'); }, child: Text('إنشاء حساب جديد'))
            ],
          ),
        ),
      ),
    );
  }
}
