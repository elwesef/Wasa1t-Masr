class PropertyModel {
  String? id;
  String? title;
  String? description;
  double? price;
  String? governorate;
  String? imageUrl;

  PropertyModel({this.id, this.title, this.description, this.price, this.governorate, this.imageUrl});

  Map<String, dynamic> toMap() => {
    'title': title,
    'description': description,
    'price': price,
    'governorate': governorate,
    'imageUrl': imageUrl,
  };

  static PropertyModel fromMap(String id, Map<String, dynamic> m) => PropertyModel(
    id: id,
    title: m['title'],
    description: m['description'],
    price: (m['price'] is int) ? (m['price'] as int).toDouble() : m['price'],
    governorate: m['governorate'],
    imageUrl: m['imageUrl'],
  );
}
