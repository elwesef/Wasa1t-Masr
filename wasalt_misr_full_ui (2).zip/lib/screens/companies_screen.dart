import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class CompaniesScreen extends StatelessWidget {
  final CollectionReference companies = FirebaseFirestore.instance.collection('companies');

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: StreamBuilder<QuerySnapshot>(
          stream: companies.orderBy('name').snapshots(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
            final docs = snapshot.data!.docs;
            if (docs.isEmpty) return Center(child: Text('لا توجد شركات مضافة بعد'));
            return ListView.builder(
              padding: EdgeInsets.all(12),
              itemCount: docs.length,
              itemBuilder: (context, i) {
                final d = docs[i].data() as Map<String,dynamic>;
                return Card(
                  child: ListTile(
                    title: Text(d['name'] ?? 'شركة'),
                    subtitle: Text(d['phone'] ?? '-'),
                    trailing: Icon(Icons.chevron_right),
                    onTap: () { /* يمكن فتح تفاصيل الشركة لاحقاً */ },
                  ),
                );
              },
            );
          },
        ),
        floatingActionButton: FloatingActionButton(
          backgroundColor: Color(0xFF0B5EA8),
          child: Icon(Icons.add_business),
          onPressed: () {
            _showAddCompany(context);
          },
        ),
      ),
    );
  }

  void _showAddCompany(BuildContext context) {
    final _name = TextEditingController();
    final _phone = TextEditingController();
    showModalBottomSheet(context: context, builder: (_){
      return Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: _name, decoration: InputDecoration(labelText: 'اسم الشركة')),
            TextField(controller: _phone, decoration: InputDecoration(labelText: 'رقم الهاتف')),
            SizedBox(height:10),
            ElevatedButton(onPressed: () async {
              if(_name.text.isNotEmpty){
                await companies.add({'name': _name.text.trim(), 'phone': _phone.text.trim()});
                Navigator.pop(context);
              }
            }, child: Text('إضافة')),
          ],),
        ),
      );
    });
  }
}
