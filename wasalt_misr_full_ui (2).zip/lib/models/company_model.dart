class CompanyModel {
  String? id;
  String? name;
  String? phone;

  CompanyModel({this.id, this.name, this.phone});

  Map<String, dynamic> toMap() => {'name': name, 'phone': phone};
}
