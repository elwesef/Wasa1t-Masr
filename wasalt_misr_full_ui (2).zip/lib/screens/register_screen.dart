import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class RegisterScreen extends StatefulWidget {
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _email = TextEditingController();
  final _pass = TextEditingController();
  bool _loading = false;
  final AuthService _auth = AuthService();

  void _register() async {
    setState(() { _loading = true; });
    try {
      await _auth.register(_email.text.trim(), _pass.text.trim());
      Navigator.pushReplacementNamed(context, '/home');
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('فشل التسجيل: \$e')));
    } finally {
      setState(() { _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text('إنشاء حساب - وصلت مصر')),
        body: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            children: [
              TextField(controller: _email, decoration: InputDecoration(labelText: 'البريد الإلكتروني')),
              TextField(controller: _pass, decoration: InputDecoration(labelText: 'كلمة المرور'), obscureText: true),
              SizedBox(height: 20),
              _loading ? CircularProgressIndicator() :
              ElevatedButton(onPressed: _register, child: Text('إنشاء حساب')),
            ],
          ),
        ),
      ),
    );
  }
}
