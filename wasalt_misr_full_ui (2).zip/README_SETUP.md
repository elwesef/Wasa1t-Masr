# وصلت مصر - Starter (Flutter + Firebase)

## نظرة عامة
هذا مشروع بداية (scaffold) لتطبيق عقارات باسم "وصلت مصر". يحتوي على شاشات تسجيل، قائمة عقارات، إضافة عقار، وتخزين عبر Firebase (تحتاج تهيئة Firebase بنفسك).

## متطلبات
- Flutter SDK مثبت (>2.17)
- Android Studio أو VS Code
- حساب Firebase

## خطوات الإعداد السريعة
1. افتح Firebase Console وأنشئ مشروع جديد (مثلاً: wasalt-misr).
2. في المشروع:
   - فعل Authentication > Sign-in method > Email/Password.
   - فعل Firestore Database (وضع التطوير مبدئياً).
   - فعل Firebase Storage لرفع الصور.
3. أضف تطبيق Android و/أو iOS في Firebase واتبع خطوات تنزيل google-services.json أو GoogleService-Info.plist.
4. انسخ ملفات التكوين إلى مجلد المشروع حسب تعليمات FlutterFire.
5. من جذر المشروع:
   - `flutter pub get`
   - `flutter run`

## ملاحظات
- الكود مبدئي ويحتاج ملفات التهيئة الخاصة بمشروع Firebase لتشغيل وظائف Auth/Firestore/Storage.
- لو تحب أجهزلك مشروع كامل موقّع وجاهز للتثبيت (APK/EXE)، أقدر أعمل ذلك لاحقًا بعد تهيئة Firebase أو بتزويدي ببعض الإعدادات.
