import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../services/auth_service.dart';
import 'add_property_screen.dart';
import 'property_detail_screen.dart';
import 'companies_screen.dart';
import 'requests_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final AuthService _auth = AuthService();
  final CollectionReference properties = FirebaseFirestore.instance.collection('properties');
  int _currentIndex = 0;
  String _search = '';

  @override
  Widget build(BuildContext context) {
    final tabs = [
      _buildPropertiesTab(),
      CompaniesScreen(),
      RequestsScreen(),
    ];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Color(0xFF0B5EA8),
          title: Row(
            children: [
              Expanded(child: Text('وصلت مصر', style: TextStyle(fontWeight: FontWeight.bold))),
              SizedBox(width:8),
              SvgPicture.asset('assets/logo.svg', height:36),
            ],
          ),
          actions: [
            IconButton(icon: Icon(Icons.exit_to_app), onPressed: () async { await _auth.signOut(); Navigator.pushReplacementNamed(context, '/login'); })
          ],
        ),
        floatingActionButton: FloatingActionButton(
          backgroundColor: Color(0xFF0B5EA8),
          onPressed: () { Navigator.push(context, MaterialPageRoute(builder: (_) => AddPropertyScreen())); },
          child: Icon(Icons.add),
        ),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (i){ setState(()=>_currentIndex=i); },
          items: [
            BottomNavigationBarItem(icon: Icon(Icons.home), label: 'الرئيسية'),
            BottomNavigationBarItem(icon: Icon(Icons.business), label: 'شركات'),
            BottomNavigationBarItem(icon: Icon(Icons.list_alt), label: 'الطلبات'),
          ],
        ),
        body: tabs[_currentIndex],
      ),
    );
  }

  Widget _buildPropertiesTab() {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.all(12),
          child: TextField(
            decoration: InputDecoration(
              hintText: 'ابحث عن عقار، محافظة، سعر...',
              prefixIcon: Icon(Icons.search),
              filled: true,
              fillColor: Colors.grey[100],
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide.none),
            ),
            onChanged: (v){ setState(()=>_search=v); },
          ),
        ),
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: properties.orderBy('createdAt', descending: true).snapshots(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
              final docs = snapshot.data!.docs.where((d){
                final m = d.data() as Map<String,dynamic>;
                final title = (m['title'] ?? '').toString();
                final gov = (m['governorate'] ?? '').toString();
                return title.contains(_search) || gov.contains(_search) || _search.isEmpty;
              }).toList();
              if (docs.isEmpty) return Center(child: Text('لا توجد عقارات بعد'));
              return GridView.builder(
                padding: EdgeInsets.symmetric(horizontal:12, vertical:8),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: MediaQuery.of(context).size.width>700?3:1, childAspectRatio: 3/1.2, mainAxisSpacing:8, crossAxisSpacing:8),
                itemCount: docs.length,
                itemBuilder: (context, i) {
                  final data = docs[i].data() as Map<String, dynamic>;
                  return GestureDetector(
                    onTap: () { Navigator.push(context, MaterialPageRoute(builder: (_) => PropertyDetailScreen(propertyId: docs[i].id))); },
                    child: Card(
                      elevation: 2,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      child: Row(
                        children: [
                          Expanded(
                            flex: 3,
                            child: Padding(
                              padding: EdgeInsets.all(8),
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                                Text(data['title'] ?? 'بدون عنوان', style: TextStyle(fontWeight: FontWeight.bold)),
                                SizedBox(height:6),
                                Text('${data['governorate'] ?? '-'} • ${data['price']?.toString() ?? '-'} ج.م', style: TextStyle(color: Colors.grey[700])),
                              ]),
                            ),
                          ),
                          Expanded(
                            flex: 2,
                            child: ClipRRect(
                              borderRadius: BorderRadius.only(topRight: Radius.circular(10), bottomRight: Radius.circular(10)),
                              child: data['imageUrl'] != null ? Image.network(data['imageUrl'], height: double.infinity, width: double.infinity, fit: BoxFit.cover) : Container(color: Colors.grey[200], child: Icon(Icons.home, size:48)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            },
          ),
        )
      ],
    );
  }
}
