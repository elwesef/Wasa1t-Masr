import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class PropertyDetailScreen extends StatelessWidget {
  final String propertyId;
  PropertyDetailScreen({required this.propertyId});

  @override
  Widget build(BuildContext context) {
    final docRef = FirebaseFirestore.instance.collection('properties').doc(propertyId);
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text('تفاصيل العقار')),
        body: FutureBuilder(
          future: docRef.get(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
            final data = (snapshot.data as DocumentSnapshot).data() as Map<String, dynamic>;
            return ListView(
              padding: EdgeInsets.all(16),
              children: [
                data['imageUrl'] != null ? Image.network(data['imageUrl'], height:220, fit: BoxFit.cover) : SizedBox(height:200, child: Center(child: Icon(Icons.home, size:80))),
                SizedBox(height:12),
                Text(data['title'] ?? '', style: TextStyle(fontSize:20, fontWeight: FontWeight.bold)),
                SizedBox(height:8),
                Row(children: [Chip(label: Text(data['governorate'] ?? '-')), SizedBox(width:8), Text('${data['price']?.toString() ?? '-'} ج.م', style: TextStyle(fontSize:16, fontWeight: FontWeight.w600))]),
                SizedBox(height:12),
                Text(data['description'] ?? ''),
                SizedBox(height:16),
                FutureBuilder(
                  future: data['companyId'] != null ? FirebaseFirestore.instance.collection('companies').doc(data['companyId']).get() : Future.value(null),
                  builder: (ctx, snap){
                    if(!snap.hasData) return SizedBox();
                    final comp = (snap.data as DocumentSnapshot).data() as Map<String,dynamic>?;
                    if(comp==null) return SizedBox();
                    return ListTile(
                      leading: Icon(Icons.business),
                      title: Text(comp['name'] ?? 'شركة'),
                      subtitle: Text(comp['phone'] ?? ''),
                    );
                  },
                ),
                SizedBox(height:12),
                ElevatedButton(onPressed: () {
                  FirebaseFirestore.instance.collection('requests').add({
                    'propertyId': propertyId,
                    'createdAt': FieldValue.serverTimestamp(),
                    'status': 'new'
                  });
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم إرسال طلب، ستتلقى رد قريبا')));
                }, child: Text('أرسل طلب تواصل')),
              ],
            );
          },
        ),
      ),
    );
  }
}
