import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseStorage _st = FirebaseStorage.instance;

  Future<String?> uploadFile(File file, String path) async {
    final ref = _st.ref().child(path);
    await ref.putFile(file);
    return await ref.getDownloadURL();
  }

  Future<void> addProperty(Map<String, dynamic> data) async {
    await _db.collection('properties').add(data);
  }
}
