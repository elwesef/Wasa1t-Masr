import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class AddPropertyScreen extends StatefulWidget {
  @override
  State<AddPropertyScreen> createState() => _AddPropertyScreenState();
}

class _AddPropertyScreenState extends State<AddPropertyScreen> {
  final _title = TextEditingController();
  final _desc = TextEditingController();
  final _price = TextEditingController();
  String _governorate = 'القاهرة';
  String? _companyId;
  File? _image;
  bool _loading = false;

  final picker = ImagePicker();

  Future pickImage() async {
    final XFile? picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 70);
    if (picked != null) setState(() { _image = File(picked.path); });
  }

  Future<String?> uploadImage(File file) async {
    final ref = FirebaseStorage.instance.ref().child('properties/${DateTime.now().millisecondsSinceEpoch}.jpg');
    await ref.putFile(file);
    return await ref.getDownloadURL();
  }

  void _save() async {
    if (_title.text.isEmpty || _price.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('الرجاء إدخال العنوان والسعر')));
      return;
    }
    setState(() { _loading = true; });
    String? imgUrl;
    if (_image != null) {
      imgUrl = await uploadImage(_image!);
    }
    await FirebaseFirestore.instance.collection('properties').add({
      'title': _title.text.trim(),
      'description': _desc.text.trim(),
      'price': double.tryParse(_price.text.trim()) ?? 0,
      'governorate': _governorate,
      'companyId': _companyId,
      'imageUrl': imgUrl,
      'createdAt': FieldValue.serverTimestamp(),
    });
    setState(() { _loading = false; });
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final companiesRef = FirebaseFirestore.instance.collection('companies');
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text('إضافة عقار جديد')),
        body: Padding(
          padding: EdgeInsets.all(16),
          child: ListView(
            children: [
              TextField(controller: _title, decoration: InputDecoration(labelText: 'عنوان العقار')),
              TextField(controller: _desc, decoration: InputDecoration(labelText: 'وصف')),
              TextField(controller: _price, decoration: InputDecoration(labelText: 'السعر'), keyboardType: TextInputType.number),
              StreamBuilder<QuerySnapshot>(
                stream: companiesRef.orderBy('name').snapshots(),
                builder: (context, snap){
                  final items = snap.hasData ? snap.data!.docs : [];
                  return DropdownButtonFormField<String>(
                    value: _companyId,
                    items: items.map<DropdownMenuItem<String>>((d){
                      final m = d.data() as Map<String,dynamic>;
                      return DropdownMenuItem(child: Text(m['name'] ?? 'شركة'), value: d.id);
                    }).toList(),
                    onChanged: (v){ setState(()=>_companyId=v); },
                    decoration: InputDecoration(labelText: 'مرتبط بشركة (اختياري)'),
                  );
                },
              ),
              DropdownButtonFormField<String>(
                value: _governorate,
                items: ['القاهرة','الجيزة','الإسكندرية','المنصورة','أسوان','السويس'].map((g) => DropdownMenuItem(child: Text(g), value: g)).toList(),
                onChanged: (v){ if (v!=null) setState(()=>_governorate=v); },
                decoration: InputDecoration(labelText: 'المحافظة'),
              ),
              SizedBox(height:10),
              _image != null ? Image.file(_image!, height: 180, fit: BoxFit.cover) : SizedBox(height:180, child: Center(child: Text('صورة العقار'))),
              Row(
                children: [
                  ElevatedButton(onPressed: pickImage, child: Text('اختر صورة')),
                  SizedBox(width:10),
                  _loading ? CircularProgressIndicator() : ElevatedButton(onPressed: _save, child: Text('حفظ')),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
