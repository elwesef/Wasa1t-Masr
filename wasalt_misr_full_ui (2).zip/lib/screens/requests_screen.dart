import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class RequestsScreen extends StatelessWidget {
  final CollectionReference requests = FirebaseFirestore.instance.collection('requests');
  final CollectionReference properties = FirebaseFirestore.instance.collection('properties');

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: StreamBuilder<QuerySnapshot>(
          stream: requests.orderBy('createdAt', descending: true).snapshots(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
            final docs = snapshot.data!.docs;
            if (docs.isEmpty) return Center(child: Text('لا توجد طلبات بعد'));
            return ListView.builder(
              itemCount: docs.length,
              padding: EdgeInsets.all(12),
              itemBuilder: (context, i) {
                final d = docs[i].data() as Map<String,dynamic>;
                return FutureBuilder(
                  future: properties.doc(d['propertyId']).get(),
                  builder: (ctx, propSnap){
                    if(!propSnap.hasData) return SizedBox();
                    final p = (propSnap.data as dynamic).data() as Map<String,dynamic>;
                    return Card(
                      child: ListTile(
                        title: Text(p['title'] ?? 'طلب على عقار'),
                        subtitle: Text('حالة: ${d['status'] ?? 'new'}'),
                        trailing: Text(p['governorate'] ?? '-'),
                        onTap: (){
                          // يمكن إضافة صفحة تفاصيل الطلب أو تغيير الحالة
                        },
                      ),
                    );
                  },
                );
              },
            );
          },
        ),
      ),
    );
  }
}
