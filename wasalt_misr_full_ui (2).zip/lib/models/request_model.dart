class RequestModel {
  String? id;
  String? propertyId;
  String? userId;
  String? status;

  RequestModel({this.id, this.propertyId, this.userId, this.status});
}
